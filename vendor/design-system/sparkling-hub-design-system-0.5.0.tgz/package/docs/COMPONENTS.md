# API pública e contratos

Importação pública: `@sparkling-hub/design-system`. Tipos são emitidos em `dist/*.d.ts`; exports em `src/index.ts`. Componentes ficam sob `.sh-theme`. O menu usa portal próprio com a mesma classe para manter tokens e tipografia.

Conteúdo editorial, imagens, tabelas, navegação, composições e componentes interativos adicionados em 0.2.0 estão documentados em [CONTENT.md](CONTENT.md), incluindo a correspondência com Bootstrap e os contratos para agentes SDD.

Na revisão 0.5.0, `Input`, `FloatingInput` e `InputGroupInput` aceitam o atributo `mask` (mesmo contrato do `MaskedInput`: valor bruto, campo oculto com `name`, mensagem padrão de validade); o `InputGroup` passou a ter um contorno único em volta de todos os controles; e `Pagination` aceita `controlSize`. Detalhes em [FORMS.md](FORMS.md#mudanças-da-050) e [CONTENT.md](CONTENT.md).

Na revisão 0.4.0, os campos ganharam `controlSize` (sm/md/lg), `success`, adornos, cores/tamanhos/descrição em Checkbox e Radio e onze controles novos (Switch, Field, FieldGroup, Radio, InputGroup, rótulos flutuantes, cartões de escolha, Chip/ChipInput, Slider/RangeSlider/NumberStepper, Autocomplete, SplitDateInput e MaskedInput). Contratos completos em [FORMS.md](FORMS.md). Tudo é aditivo: sem as props novas, os campos geram o mesmo HTML e estilo da 0.3.0.

Na revisão 0.3.0, Button, ButtonGroup, Tabs, Nav e DataTable ganharam opções de customização equivalentes às do Bootstrap 6 (detalhes abaixo e em [CONTENT.md](CONTENT.md)). Todas são aditivas: o código 0.2 continua compilando e gerando o mesmo DOM/classes.

Na revisão 0.2.1, transições e refinamentos visuais mantêm a API pública. O comportamento de movimento, camadas e redução está em [MOTION.md](MOTION.md); importar styles.css já inclui essa política. Buttons reconhecem pressão, foco dos controles aparece imediatamente e ícones usam traço consistente.

## Campos nativos

Desde 0.4.0, todos os campos abaixo aceitam também `controlSize?: "sm" | "md" | "lg"` (padrão md, ou o valor de um `ControlSizeProvider`) e `success?: string` (mensagem de confirmação ligada por `aria-describedby`; não aparece junto com `error`). `Input` aceita `startAdornment`/`endAdornment` e, desde 0.5.0, `mask` (com `value`/`defaultValue` brutos; `PasswordInput` e `Checkbox` não aceitam máscara); `Checkbox` aceita `tone` e `description`; `RadioGroup` aceita `tone`, `orientation` e `options[].description`. Ver [FORMS.md](FORMS.md).

`Input`, `PasswordInput`, `Textarea`, `Select` e `Checkbox` recebem `label: string`, `hint?: string`, `error?: string` e os atributos nativos do elemento correspondente. Encaminham ref ao controle. `id` é opcional; sem ele é gerado por useId. `name` é necessário para FormData. `value/onChange` e `defaultValue` seguem React: não misture estado controlado e não controlado. Checkbox usa `checked/onChange` ou `defaultChecked`.

| Componente    | Propriedades específicas                                                             | Contrato                                                                                                                                                         |
| ------------- | ------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Input         | `type`, `inputMode`, `min`, `max`, `step`, `pattern`, `autoComplete`, `accept`, etc. | Elemento input nativo; texto/e-mail/password/tel/url/search/number/date/time/datetime-local/month/week/file/color/range. Hidden deve usar HTML nativo sem Field. |
| PasswordInput | Atributos de Input, exceto `type`                                                    | Botão mostrar/ocultar, aria-pressed; não altera valor nem submete formulário.                                                                                    |
| Textarea      | `rows`, `maxLength`                                                                  | Quatro linhas por padrão; resize vertical. Não há contador implícito.                                                                                            |
| Select        | `options: {value,label,disabled?}[]`, `placeholder?`, `multiple?`                    | Select nativo, teclado e interação do SO. Placeholder tem valor vazio; use required se obrigatório. Múltiplo aceita array em value/defaultValue.                 |
| Checkbox      | `indeterminate?`                                                                     | Estado parcial via propriedade nativa; consumidor calcula checked/indeterminate. Estado misto não significa que todos os itens estejam selecionados.             |

`error` gera aria-invalid e inclui sua mensagem no aria-describedby. `hint` é associado sem substituir descrições externas. O texto da mensagem não é anunciado como alert em cada render; apresente um resumo de erros após tentativa de submissão e mova o foco até ele. O catálogo demonstra esse fluxo. Asterisco marca required visualmente; explique seu significado no formulário. Para campos opcionais, informe quando isso evitar dúvidas.

`disabled` retira o controle da submissão nativa e da navegação por Tab; `readOnly` mantém leitura e valor quando o elemento suporta esse atributo. Select/checkbox/radio não têm readOnly nativo: apresente um resumo textual se necessário, ou disabled acompanhado de instrução. Nunca envie valores ocultos como prova de permissão.

Input `number` não resolve moeda: contratos financeiros usam centavos inteiros; parser e apresentação são responsabilidade do produto. Input `datetime-local` não inclui fuso; converta com o fuso do estabelecimento, distinguindo data civil de instante. Input `file` apenas seleciona arquivos; validação, progresso, upload e autorização são responsabilidade da aplicação.

## RadioGroup

Props: `label`, `name`, `options: {value,label,disabled?}[]`, `value?`, `defaultValue?`, `onValueChange?(value)`, `disabled?`, `required?`, `hint?`, `error?`.

Usa fieldset/legend e radios nativos de mesmo name. Setas alternam as escolhas conforme o navegador; Tab entra/sai do grupo. Names devem ser únicos entre grupos independentes. Use para poucas opções mutuamente exclusivas. `onValueChange` entrega string, não evento.

## Ações

`Button`: atributos nativos de button + `variant: 'primary' | 'secondary' | 'ghost' | 'danger'` (primary padrão), `loading?: boolean`. Tipo padrão **button** para evitar submissões acidentais. Use `type="submit"` explicitamente. `loading` desabilita o botão e expõe aria-busy; passe texto apropriado como “Salvando…”. Não implementa idempotência de servidor. Para navegação, use link, nunca onClick que imita um href.

### Opções de estilo (0.3.0)

Desde 0.3.0 o Button tem dois eixos, como o Bootstrap 6 (`.btn-{estilo}` × `.theme-*`), sempre resolvidos com os tokens da paleta única. Todas as propriedades são opcionais e aditivas; `variant` continua válido e emite as mesmas classes `sh-button--{variant}` de 0.2.

| Propriedade  | Valores                                                                             | Padrão    | Observação                                                                                                     |
| ------------ | ----------------------------------------------------------------------------------- | --------- | -------------------------------------------------------------------------------------------------------------- |
| `appearance` | `solid`, `outline`, `subtle`, `text`, `link`                                        | `solid`   | Estilo visual. `link` parece link, mas continua sendo uma ação (button).                                       |
| `tone`       | `primary`, `secondary`, `accent`, `success`, `danger`, `warning`, `info`, `inverse` | `primary` | Papel da paleta. Ver mapeamento abaixo.                                                                        |
| `size`       | `xs` (32px), `sm` (40px), `md` (48px), `lg` (56px)                                  | `md`      | xs/sm mantêm alvo de ponteiro de 44px por pseudo-elemento; o layout continua compacto.                         |
| `shape`      | `rounded`, `pill`, `square`                                                         | `rounded` | Pílula para filtros/chips; quadrado para barras encostadas a bordas retas.                                     |
| `iconOnly`   | boolean                                                                             | false     | Quadrado sem texto visível. Exige `aria-label`/`aria-labelledby`; prefira `IconButton`.                        |
| `fullWidth`  | `true`, `"mobile"`                                                                  | —         | `true` ocupa 100%; `"mobile"` só abaixo de 40rem (substitui as utilidades `d-grid`/`md:d-block` do Bootstrap). |
| `tactile`    | boolean                                                                             | false     | Borda interna inferior. Substitui `.btn-styled` sem gradiente nem sombra externa (FOUNDATIONS.md).             |

Precedência: propriedade explícita > `variant` > padrão do `ButtonGroup`/`ButtonToolbar` > padrão do componente. `variant` combinado com `tone` mantém a aparência do variant (`variant="secondary" tone="danger"` = contorno vermelho).

| Tom         | Sólido                        | Contorno, texto, link       | Suave                         | Uso                                                     |
| ----------- | ----------------------------- | --------------------------- | ----------------------------- | ------------------------------------------------------- |
| `primary`   | Verde-azulado, texto branco   | Verde-azulado               | Névoa alternada + verde-azul. | Ação principal. Uma por região.                         |
| `secondary` | Petróleo, texto branco        | Petróleo                    | Névoa alternada + petróleo    | Ações de apoio; equivale ao `variant="secondary"`.      |
| `accent`    | Lima, **texto petróleo**      | Petróleo (nunca texto lima) | Lima suave + petróleo         | Destaque raro (novidade, convite). Não é ação primária. |
| `success`   | Igual a `primary`             | Igual a `primary`           | Igual a `primary`             | Semântica de confirmação; acompanhe com texto/ícone.    |
| `danger`    | Erro, texto branco            | Erro                        | Fundo de erro + erro          | Ações destrutivas; confirmação fica no produto.         |
| `warning`   | Fundo de aviso, texto grafite | Grafite                     | Fundo de aviso + grafite      | Pausar, adiar, revisar. Não cria nova cor.              |
| `info`      | Igual a `secondary`           | Igual a `secondary`         | Igual a `secondary`           | Semântica informativa; acompanhe com texto/ícone.       |
| `inverse`   | Branco, texto petróleo        | Branco                      | Superfície escura + branco    | **Somente sobre petróleo**. Foco lima.                  |

`success` e `info` existem para expressar intenção no código; por decisão de marca reutilizam as cores de `primary` e `secondary` (sucesso “reutiliza verde-azulado com ícone/texto”). Não dependa só da cor para comunicar o significado.

Estados: hover/pressão por tokens derivados (`color-mix` dos tokens aprovados); disabled com opacidade 0.55; `aria-pressed="true"` e escolhas marcadas mostram fundo suave + traço inferior de 3px; em sólidos, tom mais escuro + traço branco.

### Componentes de ação adicionais (0.3.0)

| API                             | Contrato                                                                                                                                                                                                                                                                                                                      |
| ------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `IconButton`                    | Props de Button exceto children/iconOnly/aria-label + `label: string` (nome acessível obrigatório) e `icon: ReactNode` decorativo. Encaminha ref, aceita Tooltip. Em `loading`, o ícone é trocado pelo spinner.                                                                                                               |
| `ButtonLink`                    | Atributos de `<a>` + opções de estilo + `disabled?`. Use para navegação real com aparência de botão. Disabled remove href e clique e expõe `aria-disabled`; o elemento deixa de ser link e sai da tabulação. Use `aria-current="page"` em grupos de links.                                                                    |
| `buttonClassName(options)`      | Retorna as classes de Button para elementos renderizados por outra biblioteca (ex.: `Link` do roteador). Ignora padrões de grupo. Não copie as classes manualmente.                                                                                                                                                           |
| `CheckboxButton`, `RadioButton` | Inputs **nativos** checkbox/radio dentro de um label com aparência de botão (Bootstrap `.btn-check`). Atributos de input (exceto type/size) + `appearance`, `tone`, `size`, `shape`, `tactile`; children é o rótulo visível. Padrão contorno/primário. Encaminham ref ao input, participam de FormData, Espaço/setas nativos. |
| `DropdownButton` (novas props)  | `appearance?`, `tone?`, `size?`, `shape?`, `hideLabel?` (gatilho só com ícone; `label` vira nome acessível — botões divididos), `icon?` (substitui o chevron), `side?: top/right/bottom/left` (bottom), `align?: start/center/end` (center).                                                                                  |

`CheckboxButton` não substitui `Checkbox` em formulários longos: use-o para filtros e preferências curtas e visuais. Para escolha exclusiva, agrupe `RadioButton` com o mesmo `name` em `ButtonGroup role="radiogroup"`. Select continua sendo o controle para listas longas; nunca troque select por DropdownButton.

`DropdownButton`: `label`, `disabled?`, `variant?`, `items: {id,label,onSelect,disabled?,destructive?}[]`. Cada callback é uma ação do aplicativo. Radix implementa foco, setas, Home/End, busca por caracteres, Escape, fechamento externo e restauração do foco. Não é select, não armazena valor de formulário. `destructive` altera aparência; confirmação e autorização ficam no produto.

### Correspondência com Bootstrap 6 — Button

Referência: [Button](https://getbootstrap.com/docs/6.0/components/button/) (6.0.0-alpha.1, consultada em 09/11/2026).

| Bootstrap 6                                              | Sparkling Hub                                                             |
| -------------------------------------------------------- | ------------------------------------------------------------------------- |
| `.btn-solid`, `.btn-outline`, `.btn-subtle`, `.btn-text` | `appearance="solid" \| "outline" \| "subtle" \| "text"`                   |
| `.btn-link`                                              | `appearance="link"` (ação) ou `ButtonLink appearance="link"` (navegação)  |
| `.theme-primary` … `.theme-inverse` (8 temas)            | `tone` com os mesmos 8 nomes, mapeados na paleta única                    |
| `.btn-styled`                                            | `tactile` — sem gradiente/sombra externa, por regra de identidade         |
| `.btn-xs`, `.btn-sm`, `.btn-lg`                          | `size="xs" \| "sm" \| "lg"`                                               |
| Playground “Rounded”: default, pill, square              | `shape="rounded" \| "pill" \| "square"`                                   |
| `.btn-icon` + `aria-label`                               | `IconButton label` (ou `iconOnly` + aria-label)                           |
| `<a class="btn">`, `.disabled` em link                   | `ButtonLink`, `ButtonLink disabled`                                       |
| `<input type="button\|submit\|reset">`                   | `Button type="submit"`/`"reset"`                                          |
| Bloco: `d-grid`, `md:d-block`, `col-6 mx-auto`           | `fullWidth` / `fullWidth="mobile"`; demais larguras por layout do produto |
| Toggle JS `data-bs-toggle="button"` + `aria-pressed`     | `ToggleButton pressed onPressedChange`                                    |
| Toggle `.btn-check` com checkbox/radio                   | `CheckboxButton`, `RadioButton`                                           |
| Variáveis `--btn-*`                                      | Tokens `--sh-btn-*` internos; não sobrescreva por produto                 |
| Ghost (exemplo Sass customizado)                         | `variant="ghost"` (legado) = `appearance="text"`                          |

## RichTextEditor

Props: `label`, `value: string`, `onChange(html: string)`, `id?`, `name?`, `hint?`, `error?`, `disabled?`, `readOnly?`. **Controlado**, browser-only. Alteração externa de value sincroniza o conteúdo sem reemitir onChange; normalizações estruturais do Tiptap podem mudar o HTML equivalente. Troca de registro deve preferir `key={recordId}` para reiniciar histórico. `name` acrescenta input hidden com HTML sanitizado; disabled remove esse input da submissão.

Comandos: negrito, itálico, título h2, listas, limpar formatação, undo/redo. Atalhos nativos do Tiptap para formatação e histórico. Toolbar é um grupo de botões comuns acessível por Tab, sem declarar um padrão ARIA toolbar que exigiria navegação roving adicional. Estado ativo usa aria-pressed. Editor tem role=textbox, aria-multiline, label e descrição. Disabled bloqueia edição/comandos; readOnly permite ler/copiar e bloqueia comandos. Não possui required nativo: o consumidor deve validar conteúdo textual sem contar tags ou `<p></p>` como preenchimento.

`sanitizeRichText(html)` utiliza DOMPurify no navegador e preserva somente p, br, strong, em, s, u, h2, h3, ul, ol, li, blockquote, code, pre, hr, sem atributos. Links, imagens, estilos, scripts e embeds são removidos. HTML de entrada, saída, colagem e input hidden passa pela política. O editor não é um visualizador seguro universal: conteúdo de API deve ser sanitizado novamente no servidor antes de persistir/renderizar. Estabeleça tamanho máximo no contrato da API; o DS não fixa limites de negócio. A biblioteca não inclui links/upload/tabelas/colaboração.

## Feedback e composição

| Componente    | API                                                                      | Uso                                                                                                                                                              |
| ------------- | ------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Alert         | `title`, `tone?: info/success/warning/error`, children, atributos de div | role=alert para erro, status nos demais. Pode sobrescrever role; para mensagem estática que não deve ser live use role=note.                                     |
| Badge         | children, `tone?: neutral/success/warning/error`                         | Rótulo textual de estado, sem interação.                                                                                                                         |
| EmptyState    | title, description, action?                                              | Ausência de dados com próxima ação. Distinguir filtro vazio de falha da API.                                                                                     |
| SettingsBlock | title, description, children, aside?                                     | Grupo contextual com descrição lateral e campos. Não cria form nem submit.                                                                                       |
| StatsBlock    | label, `items: {label,value,detail?}[]`                                  | Lista de métricas já formatadas, sem agregação ou consulta. Labels únicos por lista.                                                                             |
| StepsBlock    | current, `steps: {title,description}[]`                                  | Lista informativa, current zero-based, aria-current=step. Títulos únicos, current entre 0 e length-1. Não é navegação nem wizard; aplicativo controla progresso. |

Componentes não acessam APIs, localStorage ou dados de sessão. Mensagens no catálogo são explicitamente demonstrativas. Integrações e extensões devem seguir docs/SDD.md.
