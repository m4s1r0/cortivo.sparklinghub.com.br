# Formulários — 0.5.0

Controles de formulário ampliados com as opções das páginas de formulário do Bootstrap 6 (6.0.0-alpha.1, consultadas em 12/11/2026) e com controles de entrada que reduzem atrito: cartões de escolha, multi-select com chips, slider e stepper, autocomplete, data dividida e máscaras inteligentes. A API é própria, tipada e não depende de CSS/JS/`data-bs-*` do Bootstrap.

Leia também [COMPONENTS.md](COMPONENTS.md) (campos nativos e ações), [SDD.md](SDD.md) (regras de dados: centavos, datas civis, máscaras) e [FOUNDATIONS.md](FOUNDATIONS.md). No catálogo, o grupo **Formulário** do menu tem uma âncora por controle, com exemplos de cada variação.

## Mudanças da 0.5.0

- **Atributo `mask` nos campos de texto.** `Input`, `FloatingInput` e `InputGroupInput` aceitam `mask` e as mesmas props do `MaskedInput` (`maskOptions`, `onValueChange`, `onComplete`, `status`, `loadingMessage`, `submit`, `showBrand`, `showValidity`). O motor é o mesmo do `MaskedInput`, que passou a ser um atalho para `<Input type="text" mask={…} />` e gera o mesmo HTML de antes. `Textarea`, `FloatingTextarea`, `InputGroupTextarea` e o editor de texto rico não aceitam máscara; `PasswordInput` e `Checkbox` também não. Ver [Atributo `mask`](#atributo-mask-nos-campos-de-texto).
- **InputGroup com contorno único.** O grupo desenha uma só borda arredondada em volta de todos os controles, com divisórias internas de 1px na cor `--color-sh-line`; o foco do campo desenha o anel em volta do grupo inteiro. Antes, cada controle mantinha a própria borda e o próprio raio (o `.sh-control` vencia as regras do grupo na mesma camada), o que deixava vãos e cantos arredondados nas junções. O HTML e as classes não mudaram. Ver [Contorno](#contorno-050).
- **`controlSize` na paginação.** `Pagination` aceita `controlSize` (sm 40px, 44px em toque; md 44px, igual ao anterior; lg 56px) e herda o `ControlSizeProvider`. Ver [CONTENT.md](CONTENT.md).

Compatibilidade: sem `mask`, `Input`, `FloatingInput` e `InputGroupInput` geram o mesmo HTML da 0.4.0 (`src/compat.test.tsx` e os testes 0.4 passam sem edição). Mudanças perceptíveis: o visual do InputGroup (correção) e a `Pagination` dentro de um `ControlSizeProvider` sm/lg, que agora acompanha o tamanho. `InputProps` ganhou props opcionais: uma interface do produto que estenda `InputProps` e declare `mask`, `status` ou `submit` com outro tipo precisa renomear essas props.

## Retrocompatibilidade (0.4.0)

Todas as mudanças da 0.4.0 são aditivas. Nenhum export, prop, tipo, classe CSS, token, `id` ou rótulo do catálogo da 0.3.0 foi removido ou alterado. Sem as props novas, `Input`, `PasswordInput`, `Textarea`, `Select`, `Checkbox` e `RadioGroup` geram o mesmo HTML e o mesmo estilo computado da 0.3.0. Isso é verificado de quatro formas:

- comparação automatizada do catálogo compilado da 0.3.0 com o da 0.4.0 (HTML normalizado + 30 propriedades de estilo computado de cada elemento `sh-*`, em 1440 e 320px): idêntico;
- todos os 67 exports da 0.3.0 continuam presentes (a 0.4.0 tem 96);
- `src/compat.test.tsx` compila e executa usos 0.3 (inclusive `interface X extends InputProps` e o atributo nativo `size`);
- os testes unitários e E2E da 0.3.0 passam sem edição.

O tamanho visual usa `controlSize` (e não `size`) justamente porque `size` é atributo nativo de `<input>`/`<select>` e continua funcionando.

## Requisito → componente → teste

| Requisito                                            | API                                                                                       | Testes                                                               |
| ---------------------------------------------------- | ----------------------------------------------------------------------------------------- | -------------------------------------------------------------------- |
| Tamanhos SMALL/DEFAULT/LARGE em campos               | `controlSize="sm"\|"md"\|"lg"`, `ControlSizeProvider`                                     | `src/forms/controls.test.tsx`                                        |
| Fields, grupos, validação de sucesso                 | `Field`, `FieldGroup`, `success` em todos os campos                                       | `controls.test.tsx`                                                  |
| Checkbox/Radio com cor, tamanho e descrição          | `Checkbox` e `RadioGroup` com `tone`, `controlSize`, `description`; `Radio` avulso        | `controls.test.tsx`                                                  |
| Switch                                               | `Switch`                                                                                  | `controls.test.tsx`                                                  |
| Form adorn                                           | `Input` com `startAdornment`/`endAdornment`                                               | `controls.test.tsx`, `src/forms/integration.test.tsx`                |
| Input group                                          | `InputGroup`, `InputGroupInput`, `InputGroupSelect`, `InputGroupTextarea`, `InputAddon`   | `src/forms/input-group.test.tsx`, `tests/forms.spec.ts` (contorno)   |
| Floating labels                                      | `FloatingInput`, `FloatingSelect`, `FloatingTextarea`                                     | `input-group.test.tsx`, `tests/forms.spec.ts`                        |
| Seletores visuais (cards)                            | `ChoiceCardGroup` (radio ou checkbox)                                                     | `src/forms/choice-cards.test.tsx`                                    |
| Multi-select com chips e Chips Bootstrap             | `ChipInput` (tags livres ou opções), `Chip`                                               | `src/forms/chips.test.tsx`, `tests/forms.spec.ts`                    |
| Sliders e steppers                                   | `Slider`, `RangeSlider`, `NumberStepper`                                                  | `src/forms/numeric.test.tsx`, `tests/forms.spec.ts`                  |
| Autocomplete substituindo selects longos             | `Autocomplete`                                                                            | `src/forms/combobox.test.tsx`, `tests/forms.spec.ts`                 |
| Data dividida com avanço automático                  | `SplitDateInput`                                                                          | `src/forms/date-split.test.tsx`, `tests/forms.spec.ts`               |
| Máscaras e detecção (CPF, CNPJ, cartão, CEP, moeda…) | `MaskedInput`, `applyMask`, `isValidCpf`, `isValidCnpj`, `isValidLuhn`, `detectCardBrand` | `src/forms/masks.test.tsx`, `masked.test.tsx`, `tests/forms.spec.ts` |
| Atributo `mask` em campos de texto (0.5.0)           | `mask` em `Input`, `FloatingInput`, `InputGroupInput`; tipo `MaskFieldProps`              | `src/forms/mask-attr.test.tsx`, `tests/forms.spec.ts`                |
| Retrocompatibilidade                                 | —                                                                                         | `src/compat.test.tsx`, testes 0.3 sem edição, comparação de catálogo |

## Correspondência com o Bootstrap 6

| Bootstrap 6                                                                         | Sparkling Hub                                                                                                                     |
| ----------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| [Form control — sizes](https://getbootstrap.com/docs/6.0/forms/form-control/#sizes) | `controlSize` em todos os campos; `ControlSizeProvider` para um formulário inteiro                                                |
| [Field](https://getbootstrap.com/docs/6.0/forms/field/)                             | `.sh-field` existente, `Field` (render-prop), `FieldGroup`, `success`; card groups → `ChoiceCardGroup`; combobox → `Autocomplete` |
| [Switch](https://getbootstrap.com/docs/6.0/forms/switch/)                           | `Switch` com `tone`, `controlSize`, `description`, disabled e erro                                                                |
| [Input group](https://getbootstrap.com/docs/6.0/forms/input-group/)                 | `InputGroup` + controles, `InputAddon`, `Button`/`IconButton`/`DropdownButton`, tamanhos                                          |
| [Floating labels](https://getbootstrap.com/docs/6.0/forms/floating-labels/)         | `FloatingInput`/`FloatingSelect`/`FloatingTextarea`, `alwaysFloat`                                                                |
| [Form adorn](https://getbootstrap.com/docs/6.0/forms/form-adorn/)                   | `startAdornment`/`endAdornment` no `Input` (decorativos, nunca interativos)                                                       |
| [Chips](https://getbootstrap.com/docs/6.0/forms/chips/)                             | `Chip` (tons, ícone, avatar, seleção, remoção) e `ChipInput` (Enter/separador, Backspace, setas, colar, limite, duplicados)       |
| [Checkbox](https://getbootstrap.com/docs/6.0/forms/checkbox/)                       | `Checkbox` com `tone` (8 tons), `controlSize` (16/20/24px), `description`, parcial                                                |
| [Radio](https://getbootstrap.com/docs/6.0/forms/radio/)                             | `Radio` e `RadioGroup` com `tone`, `controlSize`, `description`, `orientation`                                                    |

Diferenças deliberadas: os tons mapeiam para a paleta única (lima só como fundo de elemento pequeno, com texto petróleo); Checkbox/Radio continuam **nativos** (cor por `accent-color`), preservando teclado, estado parcial e compatibilidade; Chips não implementam seleção múltipla de chips com Shift (remoção é por botão com nome próprio); floating labels não têm `controlSize`.

## Orientação para agentes SDD

- Prefira o label padrão acima do campo em formulários longos; use `Floating*` em telas compactas (login, filtros curtos).
- `controlSize="sm"` é para telas densas no desktop; em toque ele sobe para 44px e mantém 16px de fonte em celular. Não misture tamanhos numa mesma linha.
- 2–5 opções exclusivas e visuais → `ChoiceCardGroup`; poucas opções textuais → `RadioGroup`; mais de ~7 opções → `Autocomplete`; escolhas múltiplas pesquisáveis → `ChipInput` com `options`.
- Valores numéricos com faixa conhecida → `Slider`/`RangeSlider`; quantidades pequenas → `NumberStepper`; valores exatos grandes (preço, CPF) → campo digitado com máscara.
- Datas de nascimento ou documentos → `SplitDateInput`; datas de agenda próximas → `Input type="date"`.
- Máscara não é validação de domínio: o servidor revalida CPF/CNPJ/cartão; a busca de CEP é feita pelo produto em `onComplete`. Moeda trafega em centavos inteiros; datas como ISO civil `AAAA-MM-DD`.
- Para alternar um adorno dinamicamente sem perder o foco, passe a prop sempre (use `null` quando vazio): `endAdornment={carregando ? <Spinner /> : null}`. Apenas a ausência da prop (`undefined`) mantém o HTML 0.3.

## Fundação: tamanhos, sucesso, adornos, Checkbox, Radio, Switch, Field e FieldGroup

Tudo é aditivo: sem as novas props, o DOM e as classes de Input, PasswordInput, Textarea, Select, Checkbox e RadioGroup são idênticos ao 0.3.0.

### Tamanhos (`controlSize`)

`controlSize?: "sm" | "md" | "lg"` em Input, PasswordInput, Textarea, Select, Checkbox, RadioGroup, Switch, Radio, Field e FieldGroup. Precedência: prop > `ControlSizeProvider` > `"md"`.

| Tamanho | Altura                             | Padding       | Fonte                     | Rótulo   |
| ------- | ---------------------------------- | ------------- | ------------------------- | -------- |
| sm      | 40 px (44 px em `pointer: coarse`) | .45rem .75rem | .9375rem (1rem até 40rem) | .875rem  |
| md      | 48 px (atual)                      | .7rem .85rem  | 1rem                      | .9375rem |
| lg      | 56 px                              | .85rem 1rem   | 1.0625rem                 | 1rem     |

Textarea sm 5.5rem, lg 8.5rem; `select[multiple]` mantém 9rem. Caixa de Checkbox/Radio: 16 / 20 / 24 px. Variáveis reutilizáveis (definidas em `.sh-control`): `--sh-input-height`, `--sh-input-padding-y`, `--sh-input-padding-x`, `--sh-input-font-size`. Classes: `sh-control--sm|lg`, `sh-field--sm|lg`, `sh-choice--sm|lg`.

```tsx
<ControlSizeProvider size="sm">
  <Input label="Buscar pedidos" />
  <Button size="sm">Aplicar filtros</Button>
</ControlSizeProvider>
```

### Sucesso (`success`)

`FieldMeta` ganha `success?: string`. Renderiza `<p id="{id}-success" class="sh-success">` com ícone, cor `--color-sh-action`. Entra no `aria-describedby` depois de hint e error; se `error` existir, `success` não é exibido. Nenhum sucesso sem resposta confirmada da API.

Ordem do `aria-describedby`: do consumidor, description, hint, error ou success.

### Adornos do Input

| Prop             | Tipo        | Descrição                      |
| ---------------- | ----------- | ------------------------------ |
| `startAdornment` | `ReactNode` | Texto ou ícone antes do valor  |
| `endAdornment`   | `ReactNode` | Texto ou ícone depois do valor |

Com adornos: `<label class="sh-control sh-adorn">` envolve `<span class="sh-adorn-item" aria-hidden>` + `<input class="sh-adorn-input {className}">`. O rótulo visível externo continua sendo o nome acessível. Adornos são decorativos, nunca interativos; o significado (moeda, unidade) deve estar no rótulo ou na dica. Foco desenhado no wrapper por `:has(> input:focus-visible)`.

### Checkbox

Novas props: `tone` (8 tons), `controlSize`, `description`. A descrição fica no `aria-describedby` antes da dica; o nome acessível vem de `aria-labelledby` (só o texto do rótulo). Tom aplicado por `accent-color` (`sh-choice--tone-*`). `inverse` é para fundos petróleo (texto claro).

### Radio e RadioGroup

`RadioGroup`: `tone`, `controlSize`, `orientation: "horizontal" | "vertical"` (padrão horizontal com quebra), `options[].description`. `Radio` avulso (`forwardRef`, `label`, `description?`, `tone?`, `controlSize?`) para uso em `FieldGroup`. Teclado: setas nativas dentro do mesmo `name`.

### Switch

`Switch`: checkbox nativo com `role="switch"`, `label`, `description?`, `hint?`, `error?`, `tone?`, `controlSize?` (trilho 36×20, 44×24, 52×28), `onCheckedChange(checked)` e `onChange`. Espaço alterna. `name` entra no `FormData` (valor `on` quando ligado); `disabled` remove da submissão. Use para ajustes aplicados imediatamente; para opções enviadas num formulário prefira Checkbox. Posição, cor e forma comunicam o estado (sem texto obrigatório).

### Field e FieldGroup

- `Field`: `FieldMeta & { id?, required?, controlSize?, className?, children(control) }`. `control` traz `id`, `aria-describedby`, `aria-invalid`, `aria-required`, `required` e `className` (`sh-control` + tamanho). Serve para controles nativos ou de terceiros.
- `FieldGroup`: `fieldset/legend` com `label`, `hint`, `error`, `success`, `required`, `orientation` (`vertical` padrão), `controlSize` (fornece `ControlSizeProvider`), `disabled`.

```tsx
<Field label="Apelido" hint="Controle nativo" required>
  {(control) => <input {...control} type="text" name="alias" />}
</Field>
<FieldGroup label="Notificações">
  <Checkbox label="Resumo semanal" description="Enviado às segundas." />
  <Switch label="Modo compacto" />
</FieldGroup>
```

### Estados

Vazio: n/a. Erro e sucesso: texto + ícone, sem `role="alert"`. Disabled: opacidade e cursor; readOnly (Input) com fundo `--color-sh-ground`, inclusive com adornos. Conflito de dados é responsabilidade do produto.

### Limites

Adornos não são botões (use InputGroup). Passar a prop de adorno, mesmo como `null`, mantém a estrutura com adorno estável (sem remontar o input ao alternar o conteúdo); omiti-la mantém o HTML 0.3. A prop `size` nativa de input continua disponível; por isso o tamanho visual é `controlSize`. Foco do Switch é desenhado no trilho (o input fica transparente por cima dele).

### Correspondência Bootstrap 6

form-control sizes → `controlSize`; form-adorn → `startAdornment/endAdornment`; checkbox → `Checkbox`; radio → `Radio/RadioGroup`; switch → `Switch`; field → `Field`; form-group → `FieldGroup`.

## InputGroup (Bootstrap 6: input-group)

Une texto, ícones, botões e menus ao campo. O rótulo visível nomeia o campo principal; o wrapper é `role="group"` nomeado pelo mesmo rótulo.

### API

| Componente           | Props                                                                                                                                     | Observações                                                                                                                                   |
| -------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `InputGroup`         | `FieldMeta` (`label`, `hint?`, `error?`, `success?`) + `id?`, `required?`, `controlSize?: "sm" \| "md" \| "lg"`, `className?`, `children` | `.sh-field` > `<label for>` > `div.sh-input-group[role=group][aria-labelledby]`. Provê tamanho aos botões internos (`ButtonDefaultsContext`). |
| `InputGroupInput`    | atributos de input exceto `size` + `MaskFieldProps` (`mask`…)                                                                             | `forwardRef`. Usa `id`, `aria-describedby`, `aria-invalid` e `required` do grupo, salvo se receber `aria-label`/`aria-labelledby`.            |
| `InputGroupSelect`   | atributos de select exceto `size` + `options`, `placeholder?`                                                                             | Mesmas regras.                                                                                                                                |
| `InputGroupTextarea` | atributos de textarea                                                                                                                     | Mesmas regras; `rows` padrão 3.                                                                                                               |
| `InputAddon`         | atributos de `span`                                                                                                                       | Texto, ícone ou checkbox/radio nativo (com `aria-label`). Não é `aria-hidden`.                                                                |

Filhos diretos aceitos: `Button`, `IconButton`, `DropdownButton`, `ButtonLink`. Botões herdam a altura do tamanho do grupo; todos os itens esticam (`align-items: stretch`).

### Contorno (0.5.0)

- **Um contorno para todos os controles.** O `.sh-input-group` tem o raio `--radius-control` e um `::after` com a borda de 1px (`--sh-input-group-border`, padrão `--sh-control-border`) sobre os segmentos. Campos, addons e botões perdem a própria borda e o próprio raio; o grupo recorta os fundos (`overflow: clip`), então addons e botões sólidos acompanham os cantos arredondados.
- **Divisórias.** Entre segmentos há uma linha de 1px em `--color-sh-line` (sombra interna à esquerda), mais clara que o contorno, para separar addon, campo e botão sem desenhar cada um como uma caixa. Os auxiliares ocultos de campos com máscara não contam como segmento.
- **Altura.** Igual à de um campo isolado do mesmo tamanho: 40 (44 em toque), 48 e 56px. O contorno não soma altura, porque é desenhado por cima.
- **Estados do contorno.** Hover: petróleo. Erro (`error` ou validade da máscara): vermelho. Campo com foco: verde-azulado, com o mesmo anel de 3px/3px de um campo isolado, desenhado em volta do grupo inteiro. Botão com foco: anel interno de 2px na cor do texto do botão (branco no sólido), para identificar o segmento focado.
- **Personalização.** Para mudar a cor do contorno, redefina `--sh-input-group-border` no grupo; não reponha bordas nos filhos.

### Acessibilidade e contratos

- O input principal (sem `aria-label`) recebe o `id` do grupo; o `id` do consumidor é ignorado nele para não quebrar `label[for]`.
- Inputs adicionais exigem `aria-label` (ou `aria-labelledby`) próprio e geram id próprio. Recebem também `aria-invalid` e a descrição do grupo.
- Erro: `aria-invalid` + texto com ícone via `aria-describedby`; todo o grupo recebe a borda de erro (`sh-input-group--invalid`). Success só aparece sem erro.
- Addon de checkbox/radio: o input nativo precisa de `aria-label` descritivo (“Ativar desconto”). Em addons de texto, o significado deve estar no rótulo ou na dica.
- Teclado: Tab percorre campo e botões na ordem do DOM; nada é sequestrado. DropdownButton segue o contrato do menu (Enter/Espaço/↓ abre, Esc fecha).
- Alvos: botões seguem a altura do tamanho (sm 40px, 44px em ponteiro grosso). Addons com checkbox: o checkbox mede 20px; para alvo de 44px prefira `controlSize="md"` ou superior.

### Estados

Erro, sucesso, obrigatório, `disabled` e `readOnly` (por input). Sem estado de carregamento próprio: use `Button loading`.

### Limites

- Em 320px use no máximo dois addons/botões; o campo encolhe (`min-width: 0`), os addons não quebram linha.
- Não é ButtonGroup: não gerencia seleção nem foco entre botões.

### Exemplo

```tsx
<InputGroup label="Valor da fatura" hint="Em reais." controlSize="md">
  <InputAddon>R$</InputAddon>
  <InputGroupInput name="valor" inputMode="decimal" />
  <Button appearance="outline" tone="secondary">Aplicar</Button>
</InputGroup>

<InputGroup label="Faixa de preço">
  <InputGroupInput aria-label="Preço mínimo" />
  <InputAddon>até</InputAddon>
  <InputGroupInput aria-label="Preço máximo" />
</InputGroup>
```

### Exemplo: upload de arquivo

`InputGroupInput type="file"` usa o campo de arquivo nativo dentro do contorno do grupo: o botão de seleção do navegador fica à esquerda e o nome do arquivo ao lado. Combine-o com um botão de envio ou com um addon de ícone.

```tsx
function ComprovanteUpload({
  enviar,
}: {
  enviar: (file: File) => Promise<void>;
}) {
  const [arquivo, setArquivo] = useState<File | null>(null);
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState<string>();
  const [sucesso, setSucesso] = useState<string>();

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!arquivo) return;
    setEnviando(true);
    setErro(undefined);
    try {
      await enviar(arquivo); // o produto envia e valida no servidor
      setSucesso(`${arquivo.name} enviado.`); // só depois da resposta da API
    } catch {
      setErro("Não foi possível enviar o arquivo. Tente novamente.");
    } finally {
      setEnviando(false);
    }
  }

  return (
    <form onSubmit={onSubmit}>
      <InputGroup
        label="Comprovante de pagamento"
        hint="PDF, JPG ou PNG, até 5 MB."
        error={erro}
        success={sucesso}
        required
      >
        <InputGroupInput
          type="file"
          name="comprovante"
          accept=".pdf,.jpg,.jpeg,.png"
          onChange={(e) => {
            setArquivo(e.currentTarget.files?.[0] ?? null);
            setSucesso(undefined);
          }}
        />
        <Button
          type="submit"
          appearance="outline"
          tone="secondary"
          loading={enviando}
          disabled={!arquivo}
        >
          <Upload size={18} aria-hidden="true" />
          Enviar
        </Button>
      </InputGroup>
    </form>
  );
}

// Vários arquivos, com ícone como addon
<InputGroup label="Anexos do chamado" hint="Até 3 arquivos.">
  <InputAddon>
    <Paperclip aria-hidden="true" />
  </InputAddon>
  <InputGroupInput type="file" name="anexos" multiple />
</InputGroup>;
```

Contrato e limites do campo de arquivo:

- **Não controlado.** O React não permite definir o valor de um `input type="file"`: não passe `value`/`defaultValue`. Leia os arquivos em `onChange` (`event.currentTarget.files`) ou no `FormData` do envio. Para limpar a seleção, use `ref` (`input.value = ""`) ou remonte o campo com `key`.
- **Sem máscara.** `mask` não se aplica a arquivos.
- **Validação.** `accept` só filtra o seletor do sistema e não impede outros tipos (o usuário pode escolher "Todos os arquivos"). Tamanho, tipo real e quantidade (`multiple` não tem limite nativo) são verificados pelo produto antes do envio e repetidos no servidor; mostre o resultado em `error` do grupo, citando o arquivo ("O arquivo planilha.xlsx excede 5 MB.").
- **Estados.** Vazio: o navegador mostra "Nenhum arquivo escolhido" e o botão de envio fica `disabled`. Enviando: `Button loading`. Erro: `error` do grupo. Sucesso: `success` do grupo, só depois da resposta confirmada da API. `disabled` e `required` vão ao input como em qualquer `InputGroupInput`.
- **Texto do navegador.** "Escolher arquivo" e "Nenhum arquivo escolhido" vêm do navegador, no idioma do sistema, e não podem ser traduzidos pela biblioteca. O botão interno recebe o estilo de `::file-selector-button` (fundo `--color-sh-subtle`).
- **Telas estreitas.** Em 320px o navegador abrevia o nome do arquivo. Repita o nome escolhido num texto de apoio ou região `role="status"` ("Arquivo escolhido: comprovante.pdf").
- **Não é área de arrastar e soltar.** Upload com arrastar e soltar, pré-visualização de imagem e progresso por arquivo não fazem parte do InputGroup e exigem especificação própria.

Correspondência Bootstrap 6: `.input-group` → `InputGroup`; `.input-group-text` → `InputAddon`; botões e dropdowns (`.input-group-btn`) → `Button`/`DropdownButton` diretos; `.input-group-sm/lg` → `controlSize`. A página do Bootstrap 6 documenta a marcação e os tamanhos, mas não como bordas e foco são desenhados; o contorno único segue a referência visual do produto. Diferença: o Bootstrap só aplica estilos de validação a grupos com um único `<input>`; aqui o erro marca o grupo inteiro em qualquer composição.

## Floating labels (Bootstrap 6: floating labels)

| Componente         | Props                                                                                        | Observações                                               |
| ------------------ | -------------------------------------------------------------------------------------------- | --------------------------------------------------------- |
| `FloatingInput`    | props de `Input` exceto `startAdornment`, `endAdornment`, `controlSize` + `alwaysFloat?`     | `forwardRef` ao input. Aceita `mask` (0.5.0).             |
| `FloatingSelect`   | props de `Select` exceto `controlSize`                                                       | Rótulo sempre flutuando.                                  |
| `FloatingTextarea` | props de `Textarea` exceto `controlSize` + `height?: string` (padrão `7rem`), `alwaysFloat?` | Redimensionável na vertical; `height` é a altura inicial. |

Marcação: `.sh-field` > `.sh-floating` > controle (`.sh-control.sh-floating-control`, `placeholder=" "`) + `<label for>` depois do controle (CSS `:placeholder-shown` + `~`); o nome acessível continua vindo de `label[for]`. Altura fixa de 56px; **não há `controlSize`**. Label em repouso: 1rem muted; flutuando: 0,8125rem/650 petróleo, transição `--sh-motion-fast` (zerada em `prefers-reduced-motion`). `date`, `time`, `datetime-local`, `month`, `week`, select e `alwaysFloat` mantêm o rótulo flutuando. O placeholder real só aparece com foco ou `alwaysFloat`; nunca substitui o rótulo.

Estados: hint, erro, sucesso, `disabled`, `readOnly`, obrigatório (asterisco decorativo). Limite: rótulos longos são truncados com reticências em repouso; prefira rótulos curtos.

```tsx
<FloatingInput label="Nome do responsável" name="nome" />
<FloatingSelect label="Tipo" placeholder="Selecione" options={opcoes} />
<FloatingTextarea label="Descrição" height="9rem" />
```

## Máscaras inteligentes e data dividida

Módulos: `src/forms/masks.ts` (funções puras), `src/forms/masked.tsx` (`MaskedInput` e reexport público), `src/forms/date-split.tsx` (`SplitDateInput`), `src/forms/masked.css`.

### API pública

| Export                                                         | Tipo       | Descrição                                                                           |
| -------------------------------------------------------------- | ---------- | ----------------------------------------------------------------------------------- |
| `MaskedInput`, `MaskedInputProps`                              | componente | Campo com máscara (usa `Input` com adornos).                                        |
| `SplitDateInput`, `SplitDateInputProps`, `SplitDateParts`      | componente | Data civil em três campos.                                                          |
| `applyMask(preset, input, options?)`                           | função     | Aceita texto digitado, colado, formatado ou o `raw` anterior. Devolve `MaskResult`. |
| `isValidCpf`, `isValidCnpj`, `isValidLuhn`, `isValidCivilDate` | funções    | Validadores puros.                                                                  |
| `detectCardBrand(digits)`                                      | função     | `CardBrand                                                                          | null`. |
| `caretAfterFormat(prev, prevCaret, next)`                      | função     | Mapeia o cursor contando letras e dígitos.                                          |
| `MaskPreset`, `MaskResult`, `MaskOptions`, `CardBrand`         | tipos      |                                                                                     |

`MaskPreset`: `cpf`, `cnpj`, `cpfCnpj`, `phone`, `cep`, `currency`, `date`, `time`, `creditCard`, `cardExpiry`, `percent`.

`MaskResult`: `{ formatted, raw, complete, valid?, detail? }`. `valid` só existe quando `complete`.

| Preset     | Formato                                           | `raw`                                                        | `valid`                                                       | `detail`         |
| ---------- | ------------------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------- | ---------------- |
| cpf        | `000.000.000-00`                                  | 11 dígitos                                                   | dígitos verificadores; rejeita sequências repetidas           |                  |
| cnpj       | `00.000.000/0000-00`                              | 14 caracteres                                                | DV oficial; alfanumérico (valor = ASCII − 48); 2 DV numéricos |                  |
| cpfCnpj    | CPF até 11 dígitos; CNPJ acima disso ou com letra | idem                                                         | idem                                                          | `cpf`/`cnpj`     |
| phone      | `(00) 0000-0000` / `(00) 00000-0000`              | dígitos (sem +55)                                            | estrutural: DDD 11–99 sem zero final; celular começa com 9    | `fixo`/`celular` |
| cep        | `00000-000`                                       | 8 dígitos                                                    | n/d                                                           |                  |
| currency   | `1.250,50` (o "R$" é adorno)                      | centavos inteiros em string, sem zeros à esquerda ("" vazio) | n/d                                                           |                  |
| date       | `DD/MM/AAAA`                                      | ISO `AAAA-MM-DD` quando válida; senão os dígitos             | data civil existente                                          |                  |
| time       | `HH:MM`                                           | `HH:MM` quando válido; senão os dígitos                      | 00–23 / 00–59                                                 |                  |
| creditCard | 4-4-4-4(-3); Amex 4-6-5; Diners 4-6-4             | dígitos                                                      | Luhn                                                          | bandeira         |
| cardExpiry | `MM/AA`                                           | `MMAA`                                                       | mês 1–12 e não vencido (`options.today ?? new Date()`)        |                  |
| percent    | `15,5` (o "%" é adorno)                           | `"15.5"`                                                     | n/d                                                           |                  |

Opções (`maskOptions`): `maxDigits` (currency, 13), `decimals` (percent, 1), `max` (percent, 100), `today` (cardExpiry).

### `MaskedInput`

Props de `Input` exceto `value | defaultValue | onChange | type | maxLength | pattern`, mais:

| Prop                    | Descrição                                                                                                                                                                              |
| ----------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `mask`                  | Preset.                                                                                                                                                                                |
| `value`, `defaultValue` | Valor **bruto** (controlado ou não).                                                                                                                                                   |
| `onValueChange(result)` | A cada mudança do texto.                                                                                                                                                               |
| `onComplete(result)`    | Ao completar (ex.: buscar CEP). Dispara também para completo inválido: confira `result.valid`.                                                                                         |
| `status`                | `"idle" \| "loading"`: spinner no fim, `aria-busy` e região `role="status"` oculta (`loadingMessage`). O campo nunca é remontado ao alternar `status` (inclusive de/para `undefined`). |
| `submit`                | `"raw"` (padrão) ou `"formatted"`: o que o `<input type="hidden" name>` envia. O campo visível não tem `name`. Data e hora só enviam quando válidas.                                   |
| `showBrand`             | Cartão: bandeira como adorno e `aria-describedby` oculto "Bandeira detectada: Visa".                                                                                                   |
| `showValidity`          | Quando completo e inválido, mostra mensagem padrão se `error` não for passado.                                                                                                         |
| `maskOptions`           | Ver acima.                                                                                                                                                                             |

Padrões: `inputMode="numeric"` (texto para cnpj/cpfCnpj, com `autoCapitalize="characters"`); `autoComplete`: `tel-national`, `postal-code`, `cc-number`, `cc-exp`; `spellCheck=false`; placeholder por preset (não substitui o rótulo).

### Atributo `mask` nos campos de texto

Desde a 0.5.0, a máscara também é um atributo dos campos de texto, além do componente `MaskedInput`:

| Campo             | Com `mask`                                                                                                                                                                                                                  |
| ----------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `Input`           | Idêntico ao `MaskedInput` (que é `<Input type="text" mask={…} />`): adornos automáticos "R$", "%", bandeira e indicador de carregamento; `startAdornment`/`endAdornment` do consumidor substituem os automáticos.           |
| `FloatingInput`   | Mesmo contrato, sem adornos (o rótulo flutuante não tem adornos): ponha a unidade no rótulo ("Valor (R$)"). O placeholder do preset aparece só com foco ou `alwaysFloat`. `status="loading"` aplica `aria-busy` e anuncia.  |
| `InputGroupInput` | Mesmo contrato, sem adornos: use `InputAddon` para "R$" ou "%" e `Button loading` para indicar consulta. A mensagem padrão de validade aparece abaixo do grupo e marca o grupo inteiro; o `error` do grupo tem precedência. |

Regras comuns, iguais às do `MaskedInput`:

- `value` e `defaultValue` são o valor **bruto** (string). O campo visível não recebe `name`; um `<input type="hidden" name>` envia `raw` (ou `formatted`, com `submit="formatted"`).
- `onValueChange(result)` e `onComplete(result)` entregam `MaskResult`. O `onChange` nativo continua sendo chamado e `event.currentTarget.value` já vem formatado; para o valor bruto, use `onValueChange`.
- Não combine `mask` com `maxLength`, `pattern` ou `type` diferente de `text`/`tel`/`search`: a máscara já limita tamanho e formato.
- Mantenha `mask` estável durante a vida do campo; para trocar de preset, remonte o campo (`key`).
- O tipo das props é público: `MaskFieldProps`.

```tsx
<Input label="Telefone" mask="phone" name="telefone" />
<FloatingInput label="CPF" mask="cpf" name="cpf" />
<InputGroup label="Valor do reembolso">
  <InputAddon>R$</InputAddon>
  <InputGroupInput mask="currency" name="valor" />
  <Button appearance="outline" tone="secondary">Aplicar</Button>
</InputGroup>
```

### Comportamento de edição

- O cursor é preservado: conta-se os caracteres significativos antes do cursor e reposiciona-se depois da reformatação. Moeda e percentual mantêm o cursor no fim.
- Digitar um caractere rejeitado (letra em campo numérico) não move o cursor.
- Backspace logo depois de um separador apaga o caractere significativo anterior; Delete antes de um separador apaga o seguinte.
- Colar funciona com ou sem pontuação (telefone aceita `+55`; data aceita ISO).
- Moeda é preenchida da direita para a esquerda; nunca float.
- Controlado: o texto exibido sempre deriva do `value` do pai. Se o pai recusar a mudança, o campo volta.
- Limites: reset nativo do formulário (`form.reset()`) não restaura o estado interno de um `MaskedInput` não controlado.

### `SplitDateInput`

`FieldMeta & { value?, defaultValue?, onValueChange?(iso | null, parts), monthStyle? ("select" | "numeric"), minYear?, maxYear?, name?, required?, disabled?, readOnly?, controlSize?, autoCompletePrefix? ("bday"), partLabels?, id?, className? }`. `parts = { day, month, year, complete, valid }`.

- `<fieldset>` + `<legend>` = label; hint/error/success pelo `aria-describedby` do grupo.
- Rótulos visíveis curtos "Dia", "Mês", "Ano" (`partLabels`); nome acessível "Dia: Data de nascimento".
- Avanço automático: dia com 2 dígitos ou 1 dígito > 3 foca o mês; mês numérico com 2 dígitos ou 1 dígito > 1 foca o ano. Não avança ao editar no meio do texto nem ao apagar. O mês em `select` nunca avança sozinho. Backspace em campo vazio volta ao anterior.
- Colar `12/05/1990`, `12.05.1990`, `12051990` ou `1990-05-12` em qualquer parte distribui.
- Ao sair do grupo, dia e mês numérico de 1 dígito recebem zero à esquerda.
- Válida = data civil existente (bissextos incluídos) e dentro de `minYear`/`maxYear`. Não exibe erro sozinho: o consumidor calcula `error` com `parts`.
- `name`: hidden com ISO só quando válida. `disabled` sai da submissão. `readOnly` mantém o valor (o `select` fica `aria-readonly`, sem abrir).
- O valor é data civil, não instante UTC: não converta com `new Date(iso)` sem tratar o fuso.

### Exemplo

```tsx
<MaskedInput label="CEP" mask="cep" name="cep"
  status={buscando ? "loading" : "idle"}
  onComplete={(r) => buscarEndereco(r.raw)} />

<SplitDateInput label="Data de nascimento" name="birth" autoCompletePrefix="bday"
  onValueChange={(iso, parts) => setErro(parts.complete && !parts.valid ? "Data inexistente." : undefined)} />
```

### Acessibilidade e limites

- Labels visíveis; adornos ("R$", "%", bandeira, spinner) são `aria-hidden`; o significado fica no rótulo/dica.
- Validação da máscara é de conveniência. O servidor repete CPF/CNPJ/Luhn/data. A lista de BIN de bandeiras muda: a validação final é do processador de pagamento. Telefone tem só verificação estrutural.
- A busca de CEP é do produto (`onComplete`); a biblioteca não acessa rede.

### Correspondência Bootstrap 6

Sem equivalente direto em Bootstrap 6 (formulários nativos). `MaskedInput` ≈ form-control com `inputmode`/`autocomplete` e adornos (form-adorn); `SplitDateInput` ≈ conjunto de form-control/form-select em `fieldset`.

## Slider, RangeSlider, NumberStepper e ChoiceCardGroup

Arquivos: `src/forms/numeric.tsx`, `src/forms/choice-cards.tsx`, `src/forms/numeric.css`.

### Slider

Input `type="range"` nativo. Props de input (exceto `type|value|defaultValue|onChange|size`) mais `FieldMeta`.

| Prop                                          | Tipo                 | Padrão                                                 |
| --------------------------------------------- | -------------------- | ------------------------------------------------------ |
| `value` / `defaultValue` / `onValueChange(n)` | number               | `min`                                                  |
| `min` / `max` / `step`                        | number               | 0 / 100 / 1                                            |
| `formatValue(n)`                              | string               | número pt-BR; também `aria-valuetext` quando informado |
| `showValue`                                   | boolean              | true (`<output for>` ao lado do rótulo)                |
| `showMinMax`                                  | boolean              | true (substituído por `marks`)                         |
| `marks`                                       | `{ value, label }[]` | nenhum (decorativas, `aria-hidden`)                    |
| `tone`, `controlSize`                         | ver Fase 1           | primary, md                                            |

Teclado nativo: setas, Home, End, PageUp, PageDown. Trilho 6px (sm 4, lg 8), polegar 22px (sm 18, lg 26), área de toque de 44px. Foco: anel no polegar (WebKit e Firefox). Marcas intermediárias somem em contêineres < 20rem. `name` vai direto no input (FormData); disabled sai da submissão.

### RangeSlider

`fieldset` + `legend`, dois inputs range sobrepostos. Nomes acessíveis `"{label}: Mínimo"` e `"{label}: Máximo"` (`labels` personaliza). Os polegares não se cruzam e respeitam `minDistance`. `name` envia `{name}-min` e `{name}-max`; `names=[a,b]` define nomes explícitos. Saída `200 – 800` em `<output>`.

### NumberStepper

`input type="text" role="spinbutton"` com `aria-valuenow/min/max` (e `aria-valuetext` via `formatValue`) entre dois `IconButton` (“Diminuir {label}” / “Aumentar {label}”, `tabIndex=-1`).

| Prop                                                            | Observação                                                   |
| --------------------------------------------------------------- | ------------------------------------------------------------ |
| `value` / `defaultValue` / `onValueChange(n \| null)`           | vazio = `null`                                               |
| `min`, `max`, `step` (1), `largeStep` (10×step), `precision`    | precisão derivada de step e min                              |
| `name`                                                          | hidden com número JS (`"2.5"`); o input visível não tem name |
| `required`, `disabled`, `readOnly`, `controlSize`, `inputProps` |                                                              |

Teclado: ↑ ↓ (step), PageUp/PageDown (largeStep), Home/End (min/max, só se definidos), Enter confirma. Digitação aceita apenas dígitos, vírgula, ponto e sinal. Decimal pt-BR: `2,5`. Sem vírgula, pontos que agrupam 3 dígitos (`1.500`) são milhar; um ponto isolado (`2.5`) é decimal. No blur/Enter: arredonda à grade do step ancorada em `min` (ou 0) sem erro de ponto flutuante, aplica clamp e formata. `formatValue` afeta só `aria-valuetext`: o número visível continua editável. Sem pressionar-e-segurar.

### ChoiceCardGroup

`fieldset` + `legend` + grade de `<label class="sh-choice-card">` com input nativo (indicador no canto, focável).

| Prop                                       | Observação                                                                                  |
| ------------------------------------------ | ------------------------------------------------------------------------------------------- |
| `type`                                     | `"radio"` (padrão) ou `"checkbox"`                                                          |
| `name` (obrigatória), `options[]`          | `{ value, title, description?, icon?, meta?, disabled? }`                                   |
| `value` / `defaultValue` / `onValueChange` | string (radio) ou string[] (checkbox, na ordem das opções)                                  |
| `columns`                                  | `"auto"` (`minmax(13rem,1fr)`), 1–4; 3–4 viram 2 colunas ≤ 40rem e 1 coluna ≤ 22rem (2 → 1) |
| `required`                                 | marca os radios; ignorado em checkbox                                                       |
| `tone`, `controlSize`                      | sm compacto, lg espaçoso                                                                    |

Nome acessível do input = título (`aria-labelledby`); descrição e meta entram em `aria-describedby`. Setas nativas em radio; Espaço em checkbox. Foco desenhado no cartão (`:has(:focus-visible)`); marcado = borda 2px do tom + fundo `--color-sh-subtle` (lima-suave para `accent`, com borda petróleo). Erro: `aria-describedby`/`aria-invalid` no fieldset, bordas de erro nos cartões não marcados.

### Limites

Validação autoritativa é do servidor. Slider não tem readOnly nativo. Nenhuma biblioteca externa.

### Exemplo

```tsx
<Slider label="Volume" value={v} onValueChange={setV} formatValue={(n) => `${n}%`} />
<RangeSlider label="Preço" name="price" min={0} max={1000} minDistance={50} />
<NumberStepper label="Pessoas" name="people" min={1} max={12} />
<ChoiceCardGroup label="Plano" name="plan" options={[{ value: "a", title: "Básico", meta: "R$ 29" }]} />
```

### Correspondência Bootstrap 6

Form range → `Slider`; range duplo (sem equivalente nativo) → `RangeSlider`; input number com spinners → `NumberStepper`; check/radio “btn-check cards” → `ChoiceCardGroup`.

## Autocomplete, Chip e ChipInput

Três componentes para escolher valores em listas longas e para etiquetas. O núcleo (filtro, listbox, anúncios) é compartilhado e interno (`src/forms/combobox-core.tsx`, não exportado); só `ComboboxOption` é público.

### Autocomplete (seleção única)

Substitui `Select` quando a lista é longa. Não substitui menus de ação (`DropdownButton`).

| Prop                                                                                                          | Tipo                                       | Padrão                     | Notas                                                                                                       |
| ------------------------------------------------------------------------------------------------------------- | ------------------------------------------ | -------------------------- | ----------------------------------------------------------------------------------------------------------- |
| `label` (+ `hint`, `error`, `success`)                                                                        | `string`                                   | obrigatório                | Label sempre visível.                                                                                       |
| `options`                                                                                                     | `ComboboxOption[]`                         | obrigatório                | `{ value, label, description?, group?, disabled?, keywords? }`                                              |
| `value` / `defaultValue`                                                                                      | `string \| null`                           | `null`                     | Controlado ou não controlado.                                                                               |
| `onValueChange`                                                                                               | `(value: string \| null, option?) => void` |                            | Entrega valores, não eventos.                                                                               |
| `inputValue` / `onInputChange`                                                                                | `string` / `(text, reason) => void`        |                            | `reason`: `"input" \| "select" \| "reset" \| "clear"`. Use `reason === "input"` para disparar busca remota. |
| `loading`                                                                                                     | `boolean`                                  | `false`                    | Linha "Buscando…" + `aria-busy`.                                                                            |
| `minChars`                                                                                                    | `number`                                   | `0`                        | A lista só abre com esse número de caracteres.                                                              |
| `maxResults`                                                                                                  | `number`                                   | `50`                       |                                                                                                             |
| `allowCustomValue`                                                                                            | `boolean`                                  | `false`                    | Texto livre vira o valor ao sair do campo.                                                                  |
| `filter`                                                                                                      | `false \| (option, text) => boolean`       | filtro padrão              | `false` quando o servidor já filtra.                                                                        |
| `emptyMessage`                                                                                                | `string`                                   | "Nenhuma opção encontrada" |                                                                                                             |
| `name`, `required`, `disabled`, `readOnly`, `placeholder`, `controlSize`, `startAdornment`, `id`, `className` |                                            |                            | `ref` vai ao input.                                                                                         |

Filtro padrão: ignora acentos e caixa; ordena começo do rótulo, começo de palavra, contém, palavra-chave; destaca o trecho com `<mark class="sh-match">`.

**Acessibilidade e teclado.** Input `role="combobox"` com `aria-autocomplete="list"`, `aria-expanded`, `aria-controls`, `aria-activedescendant`; lista `role="listbox"` com `role="option"` e `aria-selected`; grupos como `role="group"`. O foco nunca sai do input (opções usam `mousedown` + `preventDefault`). Contagem de resultados anunciada em região `aria-live="polite"` com debounce de 300 ms.

| Tecla      | Efeito                                                                            |
| ---------- | --------------------------------------------------------------------------------- |
| ↓ / ↑      | Abre; navega (pula desabilitadas). ↑ na primeira opção devolve o cursor ao texto. |
| Alt+↓      | Abre sem mover a opção ativa.                                                     |
| Enter      | Seleciona a opção ativa (não envia o formulário).                                 |
| Esc        | Fecha; segundo Esc descarta o texto não confirmado.                               |
| Tab        | Fecha sem selecionar.                                                             |
| Home / End | Movem o cursor no texto.                                                          |

Blur com texto: igual (sem acento/caixa) a um rótulo seleciona; com `allowCustomValue` vira valor; senão restaura o rótulo anterior; texto apagado limpa o valor. Botões "Mostrar opções" e "Limpar {label}" têm `tabIndex=-1` (atalhos de mouse; o teclado usa o input).

**Formulário.** Um `<input type="hidden" name value>` com o `value` da opção (não o rótulo). `disabled` sai da submissão; `readOnly` mantém o valor e não abre a lista.

**Estados.** vazio (mensagem), carregando, erro, sucesso, disabled, readOnly, valor livre. **Limites.** A lista abre para baixo, sem portal e sem inversão automática: não a use dentro de contêineres com `overflow` cortado. O servidor continua responsável por validar o valor.

### Chip

`Chip({ children, tone = "secondary", icon?, avatar?, selected?, onSelectedChange?, onRemove?, removeLabel?, disabled?, className? })`. Estático = `<span>`; com `onSelectedChange` o corpo é `<button aria-pressed>`; com `onRemove` há botão "Remover {texto}" (alvo de 44 px na vertical). Tons iguais aos dos botões; `inverse` só sobre petróleo. Selecionado usa o fundo principal do tom e ícone de check (o estado não depende só da cor).

### ChipInput (tags livres e multi-select)

Props: `FieldMeta` + `value`/`defaultValue`/`onValueChange(string[])`, `options?`, `allowCreate?` (true sem options, false com), `separators?` (`[",", ";"]`; Enter sempre cria), `allowDuplicates?`, `maxItems?`, `createOnBlur?`, `validate?(text) => string | null`, `name`, `required`, `disabled`, `readOnly`, `controlSize`, `tone`, `placeholder`, `emptyMessage`, `id`.

- Sem `options`: campo de texto que cria chips. Com `options`: combobox pesquisável multisselecionável (`aria-multiselectable`), lista aberta após cada escolha; escolher uma opção marcada a remove. O chip mostra o `label`; o valor é `value`.
- Teclado no campo: Enter cria/alterna a opção ativa; separador cria; Backspace ou ← com o campo vazio focam o botão remover do último chip; Esc fecha/limpa. No chip: Backspace/Delete remove e foca o anterior (ou o campo); ←/→ navegam; → no último volta ao campo. Colar `a, b; c` cria três chips.
- Regras: `trim`; vazio ignorado; duplicado (sem acento/caixa) rejeitado; `validate` rejeita mantendo o texto; a mensagem de rejeição aparece abaixo do campo (`aria-describedby`) e é anunciada. Anúncios: "Ana adicionado. 3 itens." / "Ana removido. 2 itens." / limite atingido.
- `maxItems`: ao atingir o limite o campo vira somente leitura com `aria-disabled` (continua focável para que o foco não se perca) e a lista fecha.
- Formulário: um hidden por item com o mesmo `name`. `disabled`: sem entrada nem remoção e fora da submissão. `readOnly`: chips sem botão remover e sem campo (os valores continuam no envio).
- `required`: o atributo vai ao campo apenas enquanto não houver itens.

```tsx
<ChipInput label="Habilidades" name="skills" value={skills} onValueChange={setSkills}
  validate={(t) => (t.length < 2 ? "Use ao menos 2 caracteres." : null)} />
<ChipInput label="Destinatários" name="to" options={people} defaultValue={["ana"]} />
```

### Correspondência Bootstrap 6

Autocomplete ≈ combobox/autocomplete; Chip ≈ chip/badge removível e filter chip; ChipInput ≈ tags input / multi-select. Sem dependência de CSS/JS Bootstrap.

### Requisito → componente → teste

Combobox ARIA 1.2 → `Autocomplete`, `ChipInput` → `combobox.test.tsx`, `chips.test.tsx`.
