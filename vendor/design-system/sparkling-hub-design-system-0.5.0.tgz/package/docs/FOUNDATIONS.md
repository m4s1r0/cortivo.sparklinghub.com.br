# Fundamentos e decisões

## Direção visual

**A Centelha Organizada**, herdada do DESIGN.md raiz. O sistema atende interfaces de operação: leitura rápida, rotina frequente, formulários claros e pequenos negócios brasileiros. O catálogo é uma superfície de documentação; sua sidebar e seus exemplos não são um layout obrigatório para os produtos.

O tema inicial é claro, adequado à operação prolongada: névoa como base, branco nos campos, petróleo nos títulos e verde-azulado nas ações. Os seis SaaS usam a mesma paleta. A identidade não depende de fotografias, gradientes nem efeitos decorativos. Fios separam conteúdo; sombras se limitam a sobreposições (menus).

| Token CSS                 | Valor   | Papel                                 |
| ------------------------- | ------- | ------------------------------------- |
| `--color-sh-petroleum`    | #12343B | Títulos e estrutura                   |
| `--color-sh-action`       | #086C73 | Ação primária, links, seleção         |
| `--color-sh-action-hover` | #06575D | Hover da ação                         |
| `--color-sh-lime`         | #D9F36D | Marcador pequeno, foco sobre petróleo |
| `--color-sh-lime-soft`    | #F1FBCF | Realce contido                        |
| `--color-sh-ground`       | #F7F9F4 | Fundo                                 |
| `--color-sh-subtle`       | #EEF2EA | Superfície alternada                  |
| `--color-sh-surface`      | #FFFFFF | Campos e superfícies                  |
| `--color-sh-ink`          | #253238 | Texto                                 |
| `--color-sh-muted`        | #4A5A60 | Apoio e placeholder                   |
| `--color-sh-line`         | #D8E0DC | Fio decorativo                        |
| `--sh-control-border`     | #70847D | Borda funcional de controles          |
| `--color-sh-error`        | #B42318 | Erro com mensagem textual             |
| `--color-sh-error-bg`     | #FDECEB | Fundo de erro                         |
| `--color-sh-warning-bg`   | #FFF6D6 | Aviso com texto grafite               |
| `--color-sh-dark-surface` | #1A444C | Superfície sobre petróleo             |
| `--color-sh-dark-line`    | #2C5159 | Fio sobre petróleo                    |

A borda funcional #70847D é uma extensão para garantir contraste do contorno sobre branco; o fio decorativo claro não deve ser usado sozinho como limite de campo. Sucesso reutiliza verde-azulado com ícone/texto; aviso não ganha uma nova paleta. Lima nunca substitui a cor de texto legível.

## Escala

- Fonte Manrope Variable local, fallback system-ui. Corpo 16px/1.6; labels 15px/600–650; títulos 700. Fonte menor só em metadados, nunca como único rótulo de campo. Inputs permanecem 16px em celular. Campos têm três tamanhos (0.4.0): sm 40px (44px em telas de toque, fonte 16px até 40rem), md 48px (padrão) e lg 56px, alinhados às alturas de botão sm/md/lg. Rótulos flutuantes reduzem o rótulo a 13px/650 em petróleo quando flutuando; prefira o rótulo acima do campo em formulários longos.
- Cabeçalhos em caixa de frase, tracking -0.025em; display até -0.04em.
- Espaçamento em múltiplos de 4px: 4, 8, 12, 16, 24, 32, 48, 64. Gap de campo 8px, grupo 24px, seção 64px.
- Campos e botões 48px; alvos secundários no mínimo 44px; textarea mínimo 112px com resize vertical. Botões xs (32px) e sm (40px) mantêm alvo de 44px; lg tem 56px.
- Raios 10px para controles, 14px para painéis. O quadrado lima nunca é arredondado. Pílulas para badges pequenos.
- Foco 3px + afastamento 3px, verde-azulado em claro, petróleo em ação verde-azulada e lima em petróleo. Não use outline:none sem reposição equivalente.
- Movimento: 120ms para feedback, 160ms para conteúdo/saída e 220ms para expansão/entrada; cubic-bezier(.16,1,.3,1), com easing de saída próprio. Reduced motion remove transições e spinner animado, inclusive no backdrop, mantendo os estados e rótulos. Ver [MOTION.md](MOTION.md).
- Números operacionais com tabular-nums. Datas exibidas segundo locale/fuso da aplicação.

## Ações e variantes (0.3.0)

As opções de Button, ButtonGroup, Tabs e Nav seguem o inventário do Bootstrap 6, mas **não introduzem cores, gradientes ou sombras novas**. Decisões registradas:

- **Tons mapeados na paleta única.** `primary`/`success` = verde-azulado; `secondary`/`info` = petróleo; `danger` = erro; `warning` = fundo de aviso com texto grafite e borda funcional; `accent` = lima **somente como fundo**, sempre com texto petróleo (contorno, texto e link do tom accent usam petróleo); `inverse` = branco sobre petróleo, com foco lima. Hover e pressão derivam dos tokens por `color-mix`, sem criar novos valores na paleta.
- **Ação primária continua verde-azulada com texto branco.** Accent não é ação primária: reserve para destaques raros (convite, novidade).
- **Relevo sem gradiente.** O `.btn-styled` do Bootstrap usa gradiente e sombra; aqui `tactile` aplica apenas uma borda interna inferior de 2px. Sombras continuam restritas a sobreposições.
- **Tamanhos.** xs 32px, sm 40px, md 48px (padrão), lg 56px. xs/sm preservam o alvo de ponteiro de 44px com um pseudo-elemento invisível; use-os em barras densas e tabelas, nunca como ação principal de formulário. Em barras com vários xs, mantenha espaçamento para os alvos não se sobreporem.
- **Formas.** Raio de controle (10px) é o padrão; `pill` repete o raio de badges para filtros/chips; `square` (0) serve a barras encostadas em bordas retas. O quadrado lima continua sendo marca, não botão.
- **Abas.** `segmented` (visual 0.2) segue padrão; `tabs`, `pills` e `underline` reutilizam fio, superfície e verde-azulado. Pills ativas são verde-azuladas com texto branco, como a ação primária.
- **Seleção e alternância** mostram sempre um sinal além da cor: traço inferior de 3px (pressionado/marcado), traço de 2px (aba sublinhada) ou forma preenchida.

## Composição

Campos relacionados ficam próximos; grupos distintos têm títulos e separação maior. Priorize uma coluna em telas pequenas e no máximo duas em formulários de cadastro. Labels ficam acima, ajuda abaixo. Evite formulários inteiros em modais. A aplicação deve oferecer navegação e foco previsíveis ao mudar de rota.

Marca completa: SVG aprovado, mínimo de 240px. Para espaços menores, monograma aprovado. O catálogo usa os arquivos copiados sem alteração; confira o guia original antes de outro uso.

Na revisão 0.2.1, o catálogo usa títulos/contexto em colunas no desktop, superfícies planas brancas para demonstrações e navegação agrupada. A abertura utiliza a assinatura inversa sobre petróleo. Essas decisões pertencem à documentação; os produtos mantêm os componentes compartilhados e compõem seus próprios fluxos. Ícones Lucide recebem traço de 1.75 dentro de sh-theme.

## Governança

Fonte executável: src/styles.css. Espelho: tokens.json. Mudanças na identidade requerem decisão explícita de produto/marca, registro no changelog e avaliação de todos os consumidores. Não sobrescreva tokens por segmento. Densidade e tema escuro são extensões futuras, não variantes implicitamente suportadas por esta versão.
