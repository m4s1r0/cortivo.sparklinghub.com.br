# Verificação da versão 0.5.0

Verificação em 15/11/2026, Windows, Node.js 24.18.0, Playwright 1.64.1.

| Verificação                 | Resultado                                   | Cobertura                                                                                                                                                                                                                             |
| --------------------------- | ------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Retrocompatibilidade da API | Testes 0.4 sem edição                       | `src/compat.test.tsx`, `masked.test.tsx` (o `MaskedInput` agora usa o motor compartilhado) e os demais testes da 0.4.0 passam sem alteração; um teste compara o HTML de `Input mask` com o de `MaskedInput`                           |
| `npm run build`             | Passou                                      | TypeScript strict, biblioteca, declarações e catálogo                                                                                                                                                                                 |
| `npm test`                  | 255 testes passaram (243 anteriores + 12)   | `mask` em Input, FloatingInput e InputGroupInput (formatação, campo oculto, `onChange` formatado, controlado, mensagem de validade no campo e no grupo, `error` com precedência, input adicional); `controlSize` da paginação         |
| `npm run test:package`      | Passou                                      | Exports, tipos `MaskFieldProps`/`PaginationProps` nas declarações, `useMaskField`/`fieldAria` fora da API pública, consumidor independente                                                                                            |
| E2E (16 jornadas)           | Passaram, **em Chromium 1248, não no Edge** | 14 anteriores + 2 novas: contorno do InputGroup (segmentos sem borda/raio, `::after` de 1px/10px, alturas 40/48/56, anel no grupo com foco no campo e anel interno no botão); máscara nos três campos e alturas 40/44/56 da paginação |
| axe via Playwright          | Sem violações                               | Seção de máscaras com os novos exemplos (1440px) e as seções de formulário em 320px                                                                                                                                                   |

**Limitação:** o Edge local (`channel: 'msedge'`) continua falhando ao iniciar neste ambiente (`spawn UNKNOWN`). A suíte rodou com uma configuração temporária idêntica que troca apenas o navegador; `playwright.config.ts` não foi alterado. Rode `npm run test:e2e` no Edge antes de distribuir. Não houve comparação automatizada de catálogo 0.4 × 0.5: o InputGroup mudou de propósito, e as demais seções não tiveram CSS alterado.

# Verificação da versão 0.4.0

Verificação em 12/11/2026, Windows, Node.js 24.18.0, npm 11.16.0, Playwright 1.64.1. Implementação planejada pelo integrador e executada por agentes em fases com arquivos disjuntos; toda a verificação abaixo foi refeita pelo integrador sobre o conjunto final.

| Verificação                     | Resultado                                      | Cobertura                                                                                                                                                                                                      |
| ------------------------------- | ---------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Retrocompatibilidade visual/DOM | **Idêntico** à 0.3.0                           | Catálogo 0.3.0 compilado × 0.4.0: HTML normalizado e 30 propriedades de estilo computado de cada elemento `sh-*` nas 14 seções existentes, em 1440 e 320px                                                     |
| Retrocompatibilidade da API     | 67/67 exports da 0.3.0 presentes (96 no total) | `src/compat.test.tsx` compila e executa usos 0.3 (interfaces que estendem props públicas, `size` nativo); testes unitários e E2E da 0.3.0 sem nenhuma edição                                                   |
| `npm run build`                 | Passou                                         | TypeScript strict, biblioteca, declarações e catálogo                                                                                                                                                          |
| `npm test`                      | 243 testes passaram (33 anteriores + 210)      | Tamanhos, field, checkbox/radio/switch, adornos, input group, floating, cartões, chips, combobox, slider/stepper, máscaras (DV de CPF, CNPJ alfanumérico, Luhn, bandeiras, datas civis, cursor), data dividida |
| `npm run test:package`          | Passou                                         | Exports novos, nenhum detalhe interno exportado, consumidor 0.3 inalterado compila contra o pacote 0.4                                                                                                         |
| E2E (14 jornadas)               | Passaram — **em Chromium 1248, não no Edge**   | 10 anteriores + `tests/forms.spec.ts`: cursor da máscara no navegador, Backspace sobre separador, moeda, autocomplete/chips por teclado sem perder foco, stepper, data dividida, rótulo flutuante, 320px       |
| axe via Playwright              | Sem violações                                  | As 15 seções do grupo Formulário em 1440px e seis delas em 320px, além das jornadas anteriores                                                                                                                 |
| Overflow e console              | 0px em 320px; nenhum erro                      | Página inteira do catálogo                                                                                                                                                                                     |

**Limitação:** o Edge local (`channel: 'msedge'`) segue falhando ao iniciar neste ambiente (`spawn UNKNOWN`, antes de qualquer teste). A suíte rodou com configuração temporária idêntica trocando apenas o navegador; `playwright.config.ts` não foi alterado. Rode `npm run test:e2e` no Edge antes de distribuir.

Ajustes encontrados na integração 0.4.0:

- **Regressão de compatibilidade detectada pela comparação automatizada:** o NumberStepper usava a classe `.sh-stepper`, já pertencente ao componente `Stepper`; o Stepper existente mudava de flex para grid e gerava 41px de overflow em 320px. As classes foram renomeadas para `sh-number-stepper*`.
- Chip desabilitado e textos de slider desabilitado usavam opacidade sobre texto (falha de contraste no axe); passaram a usar cor muted (≥ 4,5:1) e borda tracejada como sinal não cromático.
- `Input` remontava ao alternar um adorno, perdendo o foco: passar a prop (mesmo `null`) agora mantém a estrutura estável; omiti-la preserva o HTML 0.3. `MaskedInput` usa isso e a região de status existe desde o primeiro render.
- O DV do CNPJ alfanumérico de exemplo (`12.ABC.345/01DE-35`) foi conferido manualmente pelo algoritmo oficial.

Limites: Safari, Firefox, dispositivos físicos, teclados virtuais e leitores de tela não foram homologados; a listbox do Autocomplete/ChipInput abre sempre para baixo e é cortada por contêineres com overflow; a lista de BINs de bandeira muda com o tempo e a validação final é do processador; `form.reset()` não restaura o estado interno de `MaskedInput` não controlado.

# Verificação da versão 0.3.0

Verificação em 09/11/2026, Windows, Node.js 24.18.0, npm 11.16.0, Playwright 1.64.1. Resultados referem-se a esta implementação local, não a uma certificação nem à homologação dos SaaS consumidores.

| Verificação            | Resultado                                     | Cobertura                                                                                                                                                                                                                                                                                                                |
| ---------------------- | --------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `npm run build`        | Passou                                        | TypeScript strict, biblioteca ESM/CSS/declarações, catálogo                                                                                                                                                                                                                                                              |
| `npm test`             | 33 testes passaram (14 anteriores + 19 novos) | Classes legadas de Button preservadas, aparência × tom, IconButton/ButtonLink/buttonClassName, CheckboxButton/RadioButton com FormData e setas, herança e isolamento de padrões de grupo, toolbar com uma parada de Tab, Tabs (aparência, keepMounted, painel único, ativação manual), Nav, caption oculta/com controles |
| `npm run test:package` | Passou                                        | Novos exports, ausência de detalhes internos no pacote, consumidor independente usando ButtonToolbar, RadioButton, IconButton, buttonClassName, Tabs underline/keepMounted e DataTable com captionActions                                                                                                                |
| E2E (10 jornadas)      | Passaram — **em Chromium 1248, não no Edge**  | 7 jornadas anteriores sem alteração + `tests/actions.spec.ts`: teclado da toolbar, botão dividido, rádios, alvo de 44px em xs, indicador alinhado nas 4 aparências e na vertical, larguras iguais em `justified`, rascunho preservado, caption oculta (altura ≤ 1px), filtro na caption, 320px sem overflow              |
| axe via Playwright     | Sem violações nos estados verificados         | wcag2a, wcag2aa, wcag21aa em #acoes, #abas e #dados-conteudo (desktop e 320px), além dos estados das jornadas anteriores                                                                                                                                                                                                 |

**Limitação desta rodada:** o Edge local (`channel: 'msedge'`) não pôde ser iniciado no ambiente de verificação (`spawn UNKNOWN` antes de qualquer teste, inclusive nos specs antigos). A suíte foi executada com uma configuração temporária idêntica à do projeto, trocando apenas o navegador pelo Chromium do Playwright; `playwright.config.ts` não foi alterado. Repita `npm run test:e2e` no Edge antes de distribuir o pacote.

Ajustes encontrados na verificação 0.3.0:

- Passar `hidden={undefined}` ao conteúdo do Radix exibia painéis inativos vazios; o override agora só ocorre com `keepMounted` (teste unitário dedicado).
- O pseudo-elemento de alvo de 44px cobria o input nativo de CheckboxButton/RadioButton; o input passou para a frente.
- O nome acessível de abas com `badge` juntava texto e contador (“Pendências3”); há espaço entre eles.
- Botões divididos sólidos pareciam um único botão; a documentação e o catálogo usam `divided`.
- Grupos encostados longos causavam overflow em 320px no catálogo; seletores com muitas opções usam grupos separados (com quebra de linha).

Não foi executado `npm audit` nesta rodada: nenhuma dependência foi adicionada ou atualizada.

# Verificação da versão 0.2.1

Verificação final em 26/10/2026, Windows, Node.js 24.18.0, npm 11.16.0, Microsoft Edge via Playwright. Resultados referem-se a esta implementação local, não a uma certificação nem à homologação dos SaaS consumidores.

| Verificação                    | Resultado                                         | Cobertura                                                                                                                                         |
| ------------------------------ | ------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------- |
| `npm run build`                | Passou                                            | TypeScript strict, biblioteca ESM/CSS/declarations, catálogo de produção                                                                          |
| `npm test`                     | 14 testes passaram                                | Contratos de formulários, sanitização, tabela, loading/vazio, paginação, slides ocultos, progresso, listas, alternância e expansão                |
| `npm run test:e2e`             | 7 jornadas passaram                               | Fluxos existentes, alinhamento de abas após troca rápida, movimento reduzido local/global, foco da navegação móvel e larguras 320/768/1024/1440px |
| axe via Playwright             | Sem violações nas páginas e estados verificados   | Tags wcag2a, wcag2aa e wcag21aa; inclui modal aberto e conteúdo em 320px                                                                          |
| `npm run test:package`         | Passou                                            | Exports, declarações, CSS, correspondência de durações CSS/JSON e build consumidor sem CSS do catálogo/plugin Tailwind                            |
| Auditoria npm das dependências | 0 vulnerabilidades reportadas na instalação 0.2.0 | Nenhuma dependência adicionada/atualizada em 0.2.1; consulta de avisos não foi repetida nesta revisão visual                                      |
| Detector de design Impeccable  | Nenhum achado                                     | Análise mecânica dos arquivos de interface                                                                                                        |

## Ajustes encontrados na verificação

- Corrigido overflow de grade de código em 320px com min-width:0 nos filhos; a página não mascara overflow globalmente.
- Exemplos de código roláveis receberam foco por teclado.
- Navegação móvel do catálogo usa o Drawer compartilhado; ao abrir contém o foco, ao fechar restaura o foco ao trigger e desmonta o conteúdo após a saída.
- Link com aparência de botão primário preserva texto branco contra a regra geral de links.
- Tokens públicos emitidos com `@theme static`, inclusive quando não usados no catálogo.
- Entrada de build separada da API de tipos para não gerar import de arquivo CSS inexistente nas declarações.
- Vitest atualizado para remover os avisos de segurança encontrados na instalação inicial.
- Links diretos por hash aguardam montagem/fonte antes de posicionar a seção; sidebar acompanha a posição de leitura.
- Tabela e exemplos de código mantêm rolagem local com acesso por teclado; não há overflow horizontal da página em 320px.
- As sobreposições receberam verificação de foco contido, Escape e restauração de foco; o menu responsivo também fecha por Escape.
- O indicador de abas acompanha a seleção e permanece alinhado após alternância e reversão; a redução local da prévia não muda a configuração do dispositivo.
- Movimento reduzido remove animação tanto no conteúdo de portal quanto no backdrop.
- Collapse fechado recebe inert/aria-hidden imediatamente, preservando conteúdo montado sem ações tabuláveis durante a saída.
- O catálogo foi inspecionado em uma rodada agrupada de desktop/celular e confirmado após a correção do teste de sequenciamento de foco. Sem rodadas adicionais de polimento após a confirmação.

## Artefatos e reprodução

As jornadas produzem screenshots em `test-results/catalog-desktop.png`, `catalog-mobile.png`, `content-interactions-desktop.png`, `content-mobile.png`, `content-drawer-mobile.png`, `polish-motion-desktop.png` e `polish-motion-mobile.png`. A pasta é ignorada e recriada nos testes. O catálogo compilado fica em `catalog/`; o pacote em `dist/`. Execute `npm run build` antes de `npm run test:package` ou `npm pack`. A distribuição 0.2.1 é `sparkling-hub-design-system-0.2.1.tgz`.

O consumidor de smoke test é `tests/consumer/`. Ele usa apenas o nome público do pacote e seu CSS, sem importar src diretamente. O bundler pode avisar que diretivas `use client` de dependências foram ignoradas e que o bundle do smoke test é grande; trata-se de uma aplicação cliente mínima, sem divisão de chunks. O catálogo principal separa o editor em um chunk. Projetos SSR/RSC devem declarar a fronteira cliente e carregar o editor sem SSR conforme README.md.

## Limites ainda aplicáveis

- Não foram homologados Safari, Firefox, dispositivos físicos ou leitores de tela. Execute essa homologação nas jornadas críticas de cada produto.
- axe e inspeção visual não substituem avaliação assistiva e validação com usuários.
- Não há backend: sucesso, exportação e dados do catálogo são demonstrações. Não há persistência, autorização, isolamento de instâncias ou upload real a validar aqui.
- Sanitização no cliente não substitui sanitização/validação no servidor. A API do produto precisa limitar tamanho de conteúdo e verificar permissões.
- O tema suportado é claro. Não se declara suporte a modo escuro, traduções completas ou todos os padrões possíveis de formulário.
- A correspondência com Bootstrap cobre os componentes e variantes listados em CONTENT.md. Não há compatibilidade de classes/plugins Bootstrap, nem autoplay/swipe do Carousel ou recursos avançados de datagrid.
- Os testes de movimento verificam geometria, foco e preferências no Edge; não medem frames por segundo em hardware físico. Altura de Accordion/Collapse é animada localmente por tempo curto; não foi acrescentado loop de animação contínuo.
