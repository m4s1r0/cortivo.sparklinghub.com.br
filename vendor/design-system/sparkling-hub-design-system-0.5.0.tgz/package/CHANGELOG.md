# Changelog

## 0.5.0 — 2026-11-15

Sem `mask`, os campos geram o mesmo HTML da 0.4.0; `MaskedInput` também gera o mesmo HTML (agora é um atalho para `Input` com `mask`). Há duas mudanças perceptíveis, descritas abaixo: o visual do InputGroup e a `Pagination` dentro de um `ControlSizeProvider`. Detalhes em [docs/FORMS.md](docs/FORMS.md#mudanças-da-050).

- **Atributo `mask`** em `Input`, `FloatingInput` e `InputGroupInput`, com as mesmas props do `MaskedInput` (`maskOptions`, `onValueChange`, `onComplete`, `status`, `loadingMessage`, `submit`, `showBrand`, `showValidity`) e o mesmo contrato: `value`/`defaultValue` brutos, campo oculto com `name`, cursor preservado e mensagem padrão de validade. No `InputGroupInput`, a mensagem aparece abaixo do grupo e marca o grupo inteiro. `FloatingInput` e `InputGroupInput` não acrescentam adornos ("R$", "%", bandeira, indicador). O `onChange` nativo recebe o texto já formatado. Textarea, editor de texto rico, `PasswordInput` e `Checkbox` não aceitam máscara. Novo tipo público `MaskFieldProps`.
- **InputGroup: contorno único (correção visual).** O grupo desenha uma só borda arredondada em volta de todos os controles, com divisórias internas claras de 1px; o foco do campo desenha o anel em volta do grupo e o foco de botão usa um anel interno. Antes, cada controle mantinha a própria borda e o próprio raio, o que deixava vãos e cantos arredondados nas junções. HTML e classes inalterados; a altura do grupo continua igual à do campo isolado (40/48/56px). Nova variável `--sh-input-group-border`.
- **Pagination: `controlSize`** sm (40px, 44px em toque), md (44px, padrão e igual ao anterior) e lg (56px), com herança do `ControlSizeProvider`. **Atenção:** uma `Pagination` que já estivesse dentro de um `ControlSizeProvider` sm/lg passa a acompanhar esse tamanho; passe `controlSize="md"` para manter o anterior. Novo tipo público `PaginationProps`.
- `InputProps` ganhou props opcionais (`mask`, `status`, `submit`, …): interfaces do produto que estendem `InputProps` e declaram props com esses nomes e outro tipo precisam renomeá-las.
- Catálogo: exemplos de `mask` nos três campos (seção Máscaras), “Upload de arquivo” no Input group (`InputGroupInput type="file"` com botão de envio e com addon de ícone) e “Tamanhos da paginação” (seção Dados). Documentação do upload, com estados e limites do campo nativo, em `docs/FORMS.md`.
- Testes: `src/forms/mask-attr.test.tsx` (11), paginação com `controlSize` em `src/content.test.tsx`, duas jornadas novas em `tests/forms.spec.ts` (contorno e foco do InputGroup; máscara nos três campos e alturas da paginação); `tests/package-check.mjs` confere os tipos novos e que o motor de máscara continua interno.

## 0.4.0 — 2026-11-12

Todas as mudanças são aditivas e retrocompatíveis: nenhum export, prop, tipo, classe, token, `id` ou rótulo do catálogo da 0.3.0 mudou; sem as props novas, os campos geram o mesmo HTML e estilo computado (verificado por comparação automatizada do catálogo 0.3.0 × 0.4.0). Detalhes em [docs/FORMS.md](docs/FORMS.md).

- **Tamanhos de campo** sm/md/lg (`controlSize`) em Input, PasswordInput, Textarea, Select, Checkbox, RadioGroup e nos novos controles; `ControlSizeProvider` para um formulário inteiro. sm sobe para 44px em telas de toque.
- **Validação de sucesso**: `success` em todos os campos e `FieldMessage`.
- **Checkbox/Radio** com `tone` (8 tons), `controlSize` e `description`; `Radio` avulso; `RadioGroup` com `orientation` e descrições por opção.
- **Novos controles do Bootstrap 6**: `Switch`, `Field`, `FieldGroup`, adornos no `Input` (`startAdornment`/`endAdornment`), `InputGroup` (+ `InputGroupInput`, `InputGroupSelect`, `InputGroupTextarea`, `InputAddon`), `FloatingInput`/`FloatingSelect`/`FloatingTextarea`, `Chip` e `ChipInput`.
- **Controles de UX**: `ChoiceCardGroup` (cartões de escolha), `ChipInput` com opções (multi-select pesquisável), `Slider`, `RangeSlider`, `NumberStepper`, `Autocomplete` (combobox ARIA 1.2), `SplitDateInput` e `MaskedInput` com presets CPF, CNPJ (inclusive alfanumérico), CPF/CNPJ, telefone, CEP, moeda (centavos inteiros), data, hora, cartão (bandeira + Luhn), validade e porcentagem; utilitários `applyMask`, `isValidCpf`, `isValidCnpj`, `isValidLuhn`, `isValidCivilDate`, `detectCardBrand`.
- Catálogo: novo grupo **Formulário** no menu, com uma âncora e exemplos para cada controle e variação (o link “Formulários” e todos os ids anteriores foram mantidos).
- Tokens: `sizePx.inputSm`, `inputMd`, `inputLg`, `inputSmTouch` em `tokens.json`.
- Testes: 210 novos testes unitários, `src/compat.test.tsx` (contrato 0.3) e `tests/forms.spec.ts` (cursor de máscara, teclado de combobox/chips/stepper, data dividida, rótulo flutuante, axe em 320px).

## 0.3.0 — 2026-11-09

Todas as mudanças são aditivas: nenhuma propriedade existente mudou de tipo ou de padrão, e o uso 0.2 gera as mesmas classes/DOM.

- **DataTable**: `hideCaption` remove a linha da caption mantendo o nome acessível; `captionActions` e `captionActionsLabel` exibem texto e controles (botões, campos, menus) na linha da caption, fora do nome da tabela e da rolagem horizontal.
- **Button**: eixos `appearance` (solid, outline, subtle, text, link) e `tone` (primary, secondary, accent, success, danger, warning, info, inverse) mapeados na paleta única; `size` (xs, sm, md, lg) com alvo de 44px em xs/sm; `shape` (rounded, pill, square); `iconOnly`; `fullWidth` (`true`/`"mobile"`); `tactile` (relevo sem gradiente). `variant` continua suportado.
- Novos: `IconButton`, `ButtonLink`, `buttonClassName`, `CheckboxButton`, `RadioButton` e `ButtonToolbar` (role toolbar com uma parada de Tab e navegação por setas/Home/End).
- **ButtonGroup**: `attached`, `orientation`, `divided` e padrões `size`/`appearance`/`tone` herdados pelos botões; aceita `role="radiogroup"`. Dialog/Drawer/Popover não herdam os padrões do grupo.
- **DropdownButton**: `appearance`, `tone`, `size`, `shape`, `hideLabel` (botões divididos), `icon`, `side` e `align`.
- **Tabs**: `appearance` (segmented, tabs, pills, underline), `justify` (start, center, end, fill, justified), `activationMode`, `keepMounted`, `instant`, `icon` e `badge` por aba.
- **Nav**: `appearance` (default, tabs, pills, underline), `justify`, `orientation` e itens `disabled`, sem semântica de tablist.
- Utilitário `.sh-visually-hidden`; tokens de altura de botão em `tokens.json` (`sizePx.buttonXs/Sm/Lg`).
- Catálogo: seções “Ações e botões” e “Abas”, demonstrações de caption de tabela; testes unitários e E2E das novas opções. Documentação, guia SDD e correspondência com Bootstrap 6 atualizados.

## 0.2.1 — 2026-10-26

- Revisão Impeccable com hierarquia editorial, superfícies de demonstração e navegação agrupada; assinatura inversa aprovada na abertura.
- Indicador de abas contínuo, expansão de Accordion/Collapse e entrada/saída de Dialog, Drawer, menus, Popover, Tooltip e Toast.
- Tokens de movimento de 120/160/220ms, easing de saída e níveis de sobreposição; redução de movimento cobre o backdrop e as raízes temáticas de portal.
- Collapse aplica inert/aria-hidden ao fechar, mantendo conteúdo e estado montados durante a transição.
- Navegação móvel do catálogo passa a usar o Drawer compartilhado, com foco contido, Escape e restauração de foco.
- Amostras de cor copiáveis, código copiável compartilhado, ícones consistentes e prévia interativa de movimento reduzido.
- API pública preservada; documentação, guia SDD, evidências e pacote de distribuição atualizados.

## 0.2.0 — 2026-10-26

- Conteúdo: Heading, Text, Prose, Blockquote, DescriptionList, ResponsiveImage, Figure, Avatar, Card e DataTable tipada.
- Navegação: Breadcrumb, ButtonGroup, ToggleButton, Nav, NavOverflow, Navbar, Pagination, Stepper e ScrollSpyNav/useScrollSpy.
- Interações: Accordion, Collapse, Tabs, Dialog, Drawer, CloseButton, Popover, Tooltip, ToastProvider/Toast e Carousel.
- Feedback: ListGroup, Skeleton, Progress e Spinner.
- Composições Tailblocks: ContentSection, FeatureGrid, HeroBlock, CalloutBlock, Gallery, TeamGrid, PricingGrid e FooterBlock, com origem e fontes preservadas.
- Catálogo ampliado com demonstrações funcionais, imagens locais rotuladas e guia de correspondência Bootstrap/SDD.
- Mantida a API de formulários existente; novas APIs são aditivas.

## 0.1.0 — 2026-10-25

- Primeira biblioteca React/TypeScript/Tailwind da Sparkling Hub, baseada na identidade aprovada.
- Campos nativos, seleção, botões, menu, feedback e editor Tiptap com allowlist HTML.
- Três blocos Tailblocks adaptados, com fontes e licença preservadas.
- Catálogo interativo e documentação técnica/SDD.
- Testes de contratos de formulários, sanitização e jornadas de navegador.
